//#include <iostream>
//#include <functional>
//using namespace std;
//#include <stack>
//#include <math.h>
//// referance
//class referanceTest
//{
//	int &a;
//public:
//	referanceTest(int &in) :a(in)
//	{
//
//	}
//	void printvalue()
//	{
//		cout <<a<< endl;
//	}
//	// by declaring referance variable in a class we are stoping to call default assignment oprattor.
//	referanceTest & operator=(const referanceTest &inval)
//	{
//		this->a = inval.a;
//		return *this;
//	}
//};
//
//int main1()
//{
//	int in1 = 10, in2 =20;
//	referanceTest a1(in1);
//	referanceTest a2(in2);
//
//	a1.printvalue();
//	a2.printvalue();
//
//	a1 = a2;  // this is not allowed once we have referance variable declrared in the class unless not define the assignment operator.
//
//
//	a1.printvalue();
//
//	cin.get();
//
//	return 0;
//}
////-------------------------2-------------------------
//class AccessPrivateVariable
//{
//	int a;
//public:
//	AccessPrivateVariable(int in) :a(in)
//	{
//		cout << a << endl;
//	}
//	void printvalue()
//	{
//		cout << a << endl;
//	}	
//};
////
////int main()
////{
////	AccessPrivateVariable obj(20);
////
////	int *p = (int*)(&obj); // this is called system heck Use static_cast in c++ to stop such kind of Hecks.
////
////	*p = 35;
////
////	cout << "Value after modification" <<*p << endl;
////
////	cin.get();
////	return 0;
////}
//
////------------------Palcement New-------------------------
//
//class PlacementNew
//{
//	int a;
//	static int count;
//public:
//	PlacementNew(int a_in):a(a_in)
//	{
//		count++;
//		cout << "Objec Number:" << count << endl;
//	}
//	void printValue()
//	{
//		cout << "function call value :" << a << endl;
//	}
//	~ PlacementNew() 
//	{
//		count--;
//		cout << "Destructor:"<< count << endl;
//	}
//};
//
////
//int PlacementNew::count = 0;
//
////int main()
////{
////	int buffermem[3*sizeof(PlacementNew)];
////	auto *memory = new(buffermem)PlacementNew(100);// nameless object temporory object.
////	auto *memory2 = new(buffermem + sizeof(PlacementNew))PlacementNew(200);
////	auto *memory3 = new(buffermem + 2*(sizeof(PlacementNew)))PlacementNew(300);
////	//auto *memory4 = new(buffermem + sizeof(PlacementNew)+ 2* (sizeof(PlacementNew)))PlacementNew(300);// stcak couroupted.
////
////	memory->printValue();
////	memory2->printValue();
////	memory3->printValue();
////
////	memory->~PlacementNew();
////	memory2->~PlacementNew();
////	memory3->~PlacementNew();
////	cin.get();
////	return 0;
////}
//
//
//#include<iostream> 
//#include<stdlib.h> 
//
//using namespace std;
//class student
//{
//	string name;
//	int age;
//public:
//	student()
//	{
//		cout << "Constructor is called\n";
//	}
//	student(string name, int age)
//	{
//		this->name = name;
//		this->age = age;
//	}
//	void display()
//	{
//		/*cout << "Name:" << this->name << endl;*/
//		cout << "Age:" << age << endl;
//	}
//	void * operator new(size_t size)
//	{
//		cout << "Overloading new operator with size: " << size << endl;
//		//void * p = ::new student();
//		void * p = malloc(size); //will also work fine 
//
//		return p;
//	}
//
//	void operator delete(void * p)
//	{
//		cout << "Overloading delete operator " << endl;
//		free(p);
//	}
//};
//
////int main()
////{
////	student * p = new student("Yash", 24);
////	cout << "size of  Student class is:" << sizeof(*p)<<endl;
////	p->display();
////	delete p;
////	cin.get();
////}
//// --------------- types function pointer---------------------------
////2-------------functor ------------
//class functor
//{
//private:
//	int x;
//public:
//	functor(int _in) :x(_in)
//	{
//
//	}
//	int operator()(int add)const
//	{
//		return add + x;
//	}
//	// use of friend function
//	friend void print(functor obj);
//};
//
//void print(functor obj)
//{
//	cout << obj.x << endl;
//}
//
////3. Std::function---------------------
//
//int odd(int x)
//{
//	cout << "i am Odd." << endl;
//	return x;
//}
//
//int even(int y)
//{
//	cout << "i am even." <<  endl;
//	return y;
//}
//std::function<int(int)>getfunct(int in)
//{
//	if (in == 1)
//		return odd;
//	else
//		return even;
//}
////int main()
////{
////	//1. ------- Lambda Expresion-------------
////	/*auto fileSizePro = [](int x) ->int
////	{
////		cout << "this is my first labda:   " << x << endl;
////		return x+x;
////	};
////
////
////	cout << "Output value: " << fileSizePro(10) <<endl;*/
////
////	//2.
////	/*functor test(20);
////	cout <<"functor Call"<< test(80) << endl;*/
////	//print(test);
////
////	//3. std function----------------
////	auto test1 = getfunct(2);
////
////	cout << "from Main. " << test1(2) << endl;
////
////	auto test2 = getfunct(1);
////
////	cout << "from Main. " << test2(1) << endl;
////
////
////	cin.get();
////	return 0;
////}
// 
//using namespace std;
//
//int findMaxLen(string str)
//{
//	int n = str.length();
//
//	// Create a stack and push -1 as initial index to it. 
//	std::stack<int> stk;
//	stk.push(-1);
//
//	// Initialize result 
//	int result = 0;
//
//	// Traverse all characters of given string 
//	for (int i = 0; i<n; i++)
//	{
//		// If opening bracket, push index of it 
//		if (str[i] == '(')
//			stk.push(i);
//
//		else // If closing bracket, i.e.,str[i] = ')' 
//		{
//			// Pop the previous opening bracket's index 
//			stk.pop();
//
//			// Check if this length formed with base of 
//			// current valid substring is more than max  
//			// so far 
//			//if (!stk.empty())
//			//	result =Max(result, i - stk.top());
//
//			//// If stack is empty. push current index as  
//			//// base for next valid substring (if any) 
//			//else stk.push(i);
//		}
//	}
//
//	return result;
//}
//
////int main()
////{
////	string str = "((()()";
////	cout << findMaxLen(str) << endl;
////
////	str = "()(()))))";
////	cout << findMaxLen(str) << endl;
////
////	return 0;
////}
//
//class base
//{
//private:
//	int i = 0;
//public:
//	void virtual print()
//	{
//		cout << "print out" << endl;
//	}
//};
//
//class derived:public  base
//{
//	int j = 0;
//public:
//	void print()
//	{
//		cout << "print out" << endl;
//	}
//};
////int main()
////{
////	base *bptr;
////	base bobj;
////	derived *dptr;
////	derived obj;
////	
////	bptr = dynamic_cast<base *>(&obj);
////
////	dptr = dynamic_cast<derived  *>(&bobj);
////	// 1. in case of non polymorphic class when we apply up casting by using dynamin cast it will give compile time error.
////	
////
////	base * bdp = new derived;
////	base *bbp =  new base;
////	derived *dp;
////
////	dp = dynamic_cast<derived *>(bdp);
////	if (dp == 0) cout << "Null pointer on first type-cast" << endl;
////	// 2. when class is poly morphic dynamin_cast performs a speccial checking during rutime to ensure that the expression yields a velid complete object of the requested calss:
////	dp = dynamic_cast<derived*>(bbp);
////	if (dp == 0) cout << "Null pointer on second type-cast" << endl;
////	cin.get();
////
////
////	//	static_cast 
////	//can perform conversions between pointers to related classes, 
////	//not only from the derived class to its base, but also from a base class to its derived.
////	//This ensures that at least the classes are compatible if the proper object is converted,
////	//but no safety check is performed during runtime to check if the object being converted is in fact a full object of the destination type.
////	//Therefore, it is up to the programmer to ensure that the conversion is safe.On the other side, 
////	//the overhead of the type - safety checks of dynamic_cast is avoided.
////
////	/*reinterpret_cast 
////	converts any pointer type to any other pointer type, 
////	even of unrelated classes. 
////	The operation result is a simple binary copy of the value from one pointer to the other. 
////	All pointer conversions are allowed: neither the content pointed nor the pointer type itself is checked.
////    It can also cast pointers to or from integer types.
////	The format in which this integer value represents a pointer is platform-specific. 
////	The only guarantee is that a pointer cast to an integer type large enough to fully contain it,
////	is granted to be able to be cast back to a valid pointer.
////	The conversions that can be performed by reinterpret_cast but not by static_cast are low-level operations,
////	whose interpretation results in code which is generally system-specific, and thus non-portable. For example:
////
////	class A {};
////	class B {};
////	A * a = new A;
////	B * b = reinterpret_cast<B*>(a);*/
////
////	// const_cast: to remove the constness
////	/*
////	This type of casting manipulates the constness of an object, either to be set or to be removed.
////	For example, in order to pass a const argument to a function that expects a non-constant parameter:
////	// const_cast
////	#include <iostream>
////	using namespace std;
////
////	void print (char * str)
////	{
////	cout << str << endl;
////	}
////
////	int main () {
////	const char * c = "sample text";
////	print ( const_cast<char *> (c) );
////	return 0;
////	}
////	*/
////
////}