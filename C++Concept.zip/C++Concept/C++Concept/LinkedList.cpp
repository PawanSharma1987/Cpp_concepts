#include <iostream>
#include<queue>

using namespace std;

//struct Node
//{
//	int data;
//	Node *link;
//};
//typedef struct Node SN;
//
//class LinkedList {
//	SN * head;
//public:
//	LinkedList(SN *in) :head(in)
//	{
//
//
//	}
//
//	void insertdata(Node *head, int value)
//	{
//		SN *temp = new SN;
//		temp->data = value;
//		temp->link = nullptr;
//		SN* start = head;
//		if (head == NULL)
//		{
//			head = temp;
//		}
//		else
//		{
//			while (start->link != nullptr)
//				start = start->link;
//
//			start->link = temp;
//		}
//
//	}
//
//	void reverseLinkedList(SN** p)
//	{
//		SN* cuu, *next, *pre;
//		pre = NULL;
//		cuu = *p;
//		while (cuu != NULL)
//		{
//			next = cuu->link;
//			cuu->link = pre;
//			pre = cuu;
//			cuu = next;
//		}
//		*p = pre;
//
//	}
//
//	void print(SN* p)
//	{
//		while (p != nullptr)
//		{
//			cout << p->data << endl;
//			p = p->link;
//		}
//	}
//
//
//	void reverseUsingRecursion(SN *p, SN**headEX)
//	{
//		if (p->link == NULL)
//		{
//			*headEX = p;
//			return;
//		}
//		reverseUsingRecursion(p->link, &(*headEX));
//		SN* q = p->link;
//		q->link = p;
//		p->link = NULL;
//	}
//};
//struct Node
//{
//	int data;
//	struct Node* left;
//	struct Node* right;
//};

/* Helper function that allocates a new node
with the given data and NULL left and right
pointers. */



// Iterative CPP program to convert a Binary 
// Tree to its mirror 
//#include<bits/stdc++.h> 
using namespace std;

/* A binary tree node has data, pointer to
left child and a pointer to right child */
struct Node
{
	int data;
	struct Node* next;
	struct Node* left;
	struct Node* right;
};
struct Node* head = nullptr;
void newNode(int data)
{
	head = new struct Node();
	head->data = data;
	head->left = head->right = nullptr;
}

void insertdata(int value)
{
	struct Node *temp = new Node;
	temp->data = value;
	if (value <= head->data)
	{
		head->left = temp;
	}
	else
	{
		head->right = temp;
	}
}
/* Helper function that allocates a new node
with the given data and NULL left and right
pointers. */
//struct Node* newNode(int data)
//{
//	struct Node* node = new Node;
//	node->data = data;
//	node->left = node->right = NULL;
//	return(node);
//}

/* Change a tree so that the roles of the  left and
right pointers are swapped at every node.
So the tree...
4
 \
2   5
 \
1   3

is changed to...
4
 \
5   2
 \
3   1
*/
void mirror(Node* root)
{
	if (root == NULL)
		return;

	queue<Node*> q;
	q.push(root);

	// Do BFS. While doing BFS, keep swapping 
	// left and right children 
	while (!q.empty())
	{
		// pop top node from queue 
		Node* curr = q.front();
		q.pop();

		// swap left child with right child 
		swap(curr->left, curr->right);

		// push left and right children 
		if (curr->left)
			q.push(curr->left);
		if (curr->right)
			q.push(curr->right);
	}
}




//--------------------------------
//	typedef uintptr_t ut;
//	void reversetwoPointers(SN**headEX)
//	{
//		struct Node* prev = NULL;
//		struct Node* current = *headEX;
//
//		// at last prev points to new head 
//		while (current != NULL) {
//			// This expression evaluates from left to right 
//			// current->next = prev, changes the link fron 
//			// next to prev node 
//			// prev = current, moves prev to current node for 
//			// next reversal of node 
//			// This example of list will clear it more 1->2->3->4 
//			// initially prev = 1, current = 2 
//			// Final expression will be current = 1^2^3^2^1, 
//			// as we know that bitwise XOR of two same 
//			// numbers will always be 0 i.e; 1^1 = 2^2 = 0 
//			// After the evaluation of expression current = 3 that 
//			// means it has been moved by one node from its 
//			// previous position 
//			current = (SN*)((ut)prev ^ (ut)current ^ (ut)(current->link) ^ (ut)(current->link = prev) ^ (ut)(prev = current));
//		}
//
//		*headEX = prev;
//	}
//};
//



int main34()
{

	cout << "Enter the List" << endl;
	int arr[] = { 19,56,99,87,65,73,82,10,23 };
	int x = 0;
	while (x < 10)
	{
		//int temp;
		//cin >> temp;
		if (head == nullptr)
		{
			newNode(arr[x]);
			x++;
		}
		else
		{
			insertdata( arr[x]);
			x++;
		}
	}
	cin.get();
	/*SN * head = new SN;
	cout << "Enter the value how much you want to print." << endl;
	int i = 0;
	cin >> i;
	head->data = i;
	head->link = nullptr;
	LinkedList obj(head);
	
	while (i > 0)
	{
		i--;
		obj.insertdata(head, i);
		
	}
	cout << "before Reversing the List." << endl;
	obj.print(head);
	*/

	//obj.reverseLinkedList(&head);
	/*obj.reverseUsingRecursion(head, &head);
	cout << "After Reversing the List." << endl;
	obj.print(head);
	cin.get();*/
	return 0;
}