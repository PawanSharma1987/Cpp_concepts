//#include <iostream>
//#include <string>
//using namespace std;
//
//signed int x = -60;
//
//unsigned int y = (unsigned)x;
//
//#define ull unsigned long long int 
//char flip(char c) { return (c == '0') ? '1' : '0'; }
//// Function to return the binary 
//// equivalent of decimal value N 
//void printOneAndTwosComplement(string bin , int &num)
//{
//	int n = bin.length();
//	int i;
//
//	string ones, twos;
//	ones = twos = "";
//
//	//  for ones complement flip every bit 
//	for (i = 0; i < n; i++)
//		ones += flip(bin[i]);
//
//	//  for two's complement go from right to left in 
//	//  ones complement and if we get 1 make, we make 
//	//  them 0 and keep going left when we get first 
//	//  0, make that 1 and go out of loop 
//	twos = ones;
//	for (i = n - 1; i >= 0; i--)
//	{
//		if (ones[i] == '1')
//			twos[i] = '0';
//		else
//		{
//			twos[i] = '1';
//			break;
//		}
//	}
//
//	// If No break : all are 1  as in 111  or  11111; 
//	// in such case, add extra 1 at beginning 
//	if (i == -1)
//		twos = '1' + twos;
//
//	for (i = 0; i < n; i++)
//	cout << twos[i] ;
//
//	num = stoi(twos);
//}
//
//int binaryToDecimal(int n)
//{
//	int num = n;
//	int dec_value = 0;
//
//	// Initializing base value to 1, i.e 2^0 
//	int base = 1;
//
//	int temp = num;
//	while (temp) {
//		int last_digit = temp % 10;
//		temp = temp / 10;
//
//		dec_value += last_digit * base;
//
//		base = base * 2;
//	}
//
//	return dec_value;
//}
//
//int decimalToBinary(int N)
//{
//
//	// To store the binary number 
//	ull B_Number = 0;
//	int cnt = 0;
//	while (N != 0) {
//		int rem = N % 2;
//		ull c = pow(10, cnt);
//		B_Number += rem * c;
//		N /= 2;
//
//		// Count used to store exponent value 
//		cnt++;
//	}
//
//	return B_Number;
//}
//
////int main()
////{
////	int num = decimalToBinary(x);
////	cout << num <<  endl;
////
////	std::string str = std::to_string(num);
////
////	printOneAndTwosComplement(str, num);
////
////	int Unew_numvalue = binaryToDecimal(num);
////
////	cout <<"this is unsigned value of -60"<< endl;
////	cout << Unew_numvalue << endl;
////	cin.get();
////	return 0;
////}