#include <iostream>
#include <vector>
using namespace std;


//bool ToMini::isFilesEqual(std::filesystem::path lFilePath_in, std::filesystem::path rFilePath_in)
//{
//auto lFilePath = lFilePath_in / L"data.xray.mini";
//auto rFilePath = rFilePath_in / L"data.xray.mini";
//std::ifstream lFile(lFilePath.c_str(), std::ifstream::in | std::ifstream::binary);
//std::ifstream rFile(rFilePath.c_str(), std::ifstream::in | std::ifstream::binary);
//
//if (!lFile.is_open() || !rFile.is_open())
//{
//return false;
//}
//
//
//auto fileSizePro = [](std::ifstream& fileIn) ->size_t
//{
//fileIn.seekg(0, fileIn.end);
//auto lengthL = fileIn.tellg();
//fileIn.seekg(0, fileIn.beg);
//return lengthL;
//
//};
//
//auto siezeL = fileSizePro(lFile);
//auto siezeR = fileSizePro(rFile);
//siezeL = siezeL; siezeR = siezeR;
//
//const int blockSize = 1024 * 1024;
//char *lBuffer = new char[blockSize];
//char *rBuffer = new char[blockSize];
//
//do {
//	memset(lBuffer, 0, blockSize);
//	memset(rBuffer, 0, blockSize);
//
//	lFile.read(lBuffer, blockSize);
//	rFile.read(rBuffer, blockSize);
//
//	const auto ret = memcmp(lBuffer, rBuffer, blockSize);
//	if (ret != 0)
//	{
//		auto lengthL = lFile.tellg();
//		auto lengthR = rFile.tellg();
//		lengthL = lengthL; lengthR = lengthR;
//
//		delete[] lBuffer;
//		delete[] rBuffer;
//		return false;
//	}
//} while (!lFile.eof() || !rFile.eof());
//
//delete[] lBuffer;
//delete[] rBuffer;
//return true;
//
//}



//void ToMini::testToMini()
//{
//	char szMaxPath[MAX_PATH];
//	GetModuleFileNameA(NULL, szMaxPath, sizeof(szMaxPath));
//	auto modulePath = std::filesystem::path(szMaxPath).remove_filename();
//	auto input = modulePath / L"Dicom";
//	auto outputdir = modulePath / L"debugerroOutput";
//	std::filesystem::create_directory(outputdir);
//	//volume.metadata.conversionIntercept
//	auto errorcode = CT::toMini(input, outputdir);
//	errorcode = errorcode;
//
//}

int splitcount(int arr[], int l,int right)
{
	int index=l;
	int count = l;
	int povit = arr[right];
	
	while( count < right)
	{
		if (povit > arr[count])
		{
			auto swap = [](int &x, int &y)->void
			{
				int temp;
				temp = x;
				x = y;
				y = temp;

			};
			swap(arr[count], arr[index]);
			index++;
		}
		count++;
	}
	swap(arr[index], arr[count]);
	return index;
}

void quicksort(int array[], int l, int r)
{
	if (l < r)
	{

		int val = splitcount(array, l, r);
		quicksort(array, 0, val - 1);
		quicksort(array, val + 1, r);
	}
}

//----------------------Merge Sort------------
//void mergeit(int arrar[], int left, int mid, int right)
//{
//	int i, j, k;
//	const int leftsizearray = mid - left + 1;
//	const int rightsizearray = right - mid;
//	std::vector<int> leftside;//= new int[leftsizearray];
//	std::vector<int>rightside;//= new int[rightsizearray];
//
//	// fill the left and right array
//	for (i = 0; i < leftsizearray; i++)
//	{
//		leftside.push_back(arrar[left + i]);
//	}
//
//	for (j = 0; j < rightsizearray; j++)
//	{
//		rightside.push_back(arrar[mid + 1 + j]);
//	}
//
//	i = 0; j = 0; k = 1;
//
//	// compare left and right array
//	while (i < leftsizearray && j < rightsizearray)
//	{
//		if (leftside[i] <= rightside[j])
//		{
//			arrar[k] = leftside[i];
//			i++;
//		}
//		else
//		{
//			arrar[k] = rightside[j];
//			j++;
//		}
//		k++;
//	}
//
//	// fill the left over elements.
//	while (i < leftsizearray)
//	{
//		arrar[k] = leftside[i];
//		k++;
//		i++;
//	}
//	while (j < rightsizearray)
//	{
//		arrar[k] = rightside[j];
//		k++;
//		j++;
//	}
//
//	//delete[]leftside;
//	//delete[]rightside;
//}
//void Mergesort(int arrar[], int left, int right)
//{
//	breakit(arrar, left, right);
//}

void merge(int arr[], int l, int m, int r);
void Mergesort(int arrar[], int left, int right)
{
	if (left < right)
	{
		int mid = left + (right - left)/2;
		Mergesort(arrar, left, mid);
		Mergesort(arrar, mid + 1, right);
		merge(arrar, left, mid, right);
	}
}



// Merges two subarrays of arr[]. 
// First subarray is arr[l..m] 
// Second subarray is arr[m+1..r] 
void merge(int arr[], int l, int m, int r)
{
	int i, j, k;
	const int n1 = m - l + 1;
	const int n2 = r - m;
	
	/* create temp arrays */
	std::vector<int> L;
	std::vector<int> R;

	/* Copy data to temp arrays L[] and R[] */
	for (i = 0; i < n1; i++)
	{
		L.push_back(arr[l + i]);
	}
	for (j = 0; j < n2; j++)
		R.push_back(arr[m + 1 + j]);

	/* Merge the temp arrays back into arr[l..r]*/
	i = 0; // Initial index of first subarray 
	j = 0; // Initial index of second subarray 
	k = l; // Initial index of merged subarray 
	while (i < n1 && j < n2)
	{
		if (L[i] <= R[j])
		{
			arr[k] = L[i];
			i++;
		}
		else
		{
			arr[k] = R[j];
			j++;
		}
		k++;
	}

	/* Copy the remaining elements of L[], if there
	are any */
	while (i < n1)
	{
		arr[k] = L[i];
		i++;
		k++;
	}

	/* Copy the remaining elements of R[], if there
	are any */
	while (j < n2)
	{
		arr[k] = R[j];
		j++;
		k++;
	}
}

/* l is for left index and r is right index of the
sub-array of arr to be sorted */
void mergeSort(int arr[], int l, int r)
{
	if (l < r)
	{
		// Same as (l+r)/2, but avoids overflow for 
		// large l and h 
		int m = l + (r - l) / 2;

		// Sort first and second halves 
		mergeSort(arr, l, m);
		mergeSort(arr, m + 1, r);

		merge(arr, l, m, r);
	}
}

int main9()
{
	int array[10] = {100,3,98,15,7,9,6,2,18,10};
	cout << "enter the arry." << endl;
	int k = 0;
	while (k < 10)
	{
		cin >> array[k];
		k++;
	}
	
	quicksort(array, 0, 9);
	/*Mergesort(array, 0, 9);
	cout << "Sorted Output:" << endl;
	int i = 0;
	while (i < 10)
	{
		
		cout << array[i] << endl;
		i++;
	}*/
	cin.get();
	return 0;
}