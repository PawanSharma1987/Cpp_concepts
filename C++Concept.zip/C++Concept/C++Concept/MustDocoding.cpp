#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int findTriplets(std::vector<int> input)
{
	int len = 0;
	std::sort(std::begin(input), std::end(input));

	for (int i = input.size() - 1; i >= 0; i--) {
		int j = 0;
		int k = i - 1;
		while (j < k)
		{
			if (input[i] == input[j] + input[k])
			{
				len++; j++; k--;
			}
			else if (input[i] > input[j] + input[k])
				j++;
			else
				k--;
		}
	}
	return len;
	


}
int main2()
{
	std::vector<int> input;
	int size;
	cout << "Enter the size" << endl;
	cin >> size;
	for (int i = 0; i < size; ++i)
	{
		int val;
		cout << "Enter the value" << endl;
		cin >> val;
		input.push_back(val);
	}
	
	cout << "\n";

	auto ans = findTriplets(input);
	if (ans)
		cout << ans << endl;
	else
		cout << "-1" << endl;

	cin.get();
	return 0;
}