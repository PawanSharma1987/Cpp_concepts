// inhertance.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;

// prefer composition over inheritace.
// Inheritance - tight coupling - Ia A relatioship
// inheritance: reuse the relationship property. it uses complete code reuse.
// ripple effect. any change in the parent class it will effect the derived classes.
// inheritace is one way relatioship.
// is a staic
// peter Priciple: child should have more functionalities than parent.
// oreder of const call from base to derive
// order of des call derive to base in hirerchy.
// 

// Composition - Loose coupling - has a Relationship
// no ripple effect.
// lazy instatiation.
// has a is dynamic 


// always to implement interface we need inheritance
// C++ program to explain 
// multiple inheritance 


// multiple Inheritace
// first base class 

class Diamond
{
public:
	int i;

	Diamond(int w =5) :i(w)
	{
		
		cout << "value of i in Diamond  = " <<i<< endl;
	}
	void fun()
	{
		cout << "fun()->Diamond" << endl;
	}
};

class Vehicle : virtual public  Diamond
{

public:
	Vehicle(int x):Diamond(x)
	{		
		cout << "value of i in Vehicle  = " << i << endl;
	}

	~Vehicle()
	{
		cout << "Des of Vehicle" << endl;
	}

	
};

// second base class 
class  FourWheeler: virtual public Diamond
{
public:
	FourWheeler(int y):Diamond(y)
	{
		
		cout << "value of i in FourWheeler  = " << i << endl;
	}

	~FourWheeler()
	{
		cout << "Des of 4 wheeler Vehicle" << endl;
	}

	
};


class Car :  public Vehicle,  public FourWheeler
{
public:
	Car():FourWheeler(20),Vehicle(10)
	{
		cout << "this is pointing to "<<this << endl;
		cout << "This is car!" << endl;
	}

	~Car()
	{
		cout << "Des of car!" << endl;
	}	

};

//int &&ref = 30;

// main function 
//int main()
//{
//	// creating object of sub class will 
//	// invoke the constructor of base classes 
//	Car obj;
//	return 0;
//}

//---------------------------------------------------



// C++ Implementation to show that a derived class 
// doesn�t inherit access to private data members. 
// However, it does inherit a full parent object 

class A
{
public:
	int x;
protected:
	int y;
private:
	int z;
};

class B : public A
{
	// x is public 
	// y is protected 
	// z is not accessible from B 
};

class C : protected A
{
	// x is protected 
	// y is protected 
	// z is not accessible from C 
};

class D : private A // 'private' is default for classes 
{
	// x is private 
	// y is private 
	// z is not accessible from D 
};

class base
{
public:
	void fun()
	{
		cout << "base" << endl;
	}
};

class derive: public base
{
public:
	void fun()
	{
		cout << "base" << endl;
	}
};

int main()
{
	Car obj;
	cout << "sizeof Vehicle =" << sizeof(Vehicle) << endl;
	cout << "sizeof FourWheeler =" << sizeof(FourWheeler) << endl;
	cout << "sizeof Car =" << sizeof(obj) << endl;
	obj.fun();
	//Car obj;
	//obj.Vehicle::fun();
	//obj.FourWheeler::fun();
	// this is to reolve the ambiguty in the in multiple inheritance

	cin.get();
    return 0;
}

