// polymorphism.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;
// Polymorphis many forms.
// Static: early bind: compile time
/* name mangling :-
1. no of args
2. types of argument.
3. order of arguments.

-> operator overloding
::, .,?:,
insertion and extrection must be overlaoded as a friend fun
conversion operator() thatshould be member fun
-> funtion overloding
funtion overloding is a concept of scope.
Ques: why not return type?
*/

//Dynamic: late bind: runtime
/*

Inheritance + overriding = runtime polymorphism // upcasting

*/
class base
{
public:

	void fun(int x)
	{
		cout << "non const" << endl;
	}

	/*void fun(int x) const
	{
		cout << "const" << endl;
	}*/

	void fun2(int x) const
	{
		cout << "const" << endl;
	}
	/*void* operator new (size_t size)
	{

	}*/


};

class derived : public base
{
public:
	void fun()
	{

	}
	//void fun(int x);
};


int main()
{	
	base *p = new base;//

	base b1;
	b1.fun(5);
	b1.fun2(7);// non const can acces const function
	const base b2;//const can not access non const member function.
//	b2.fun(5);

	

	return 0;
}

