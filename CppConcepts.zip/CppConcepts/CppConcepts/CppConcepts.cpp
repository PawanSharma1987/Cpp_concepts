// CppConcepts.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;
// thigs toDo:
// calling convention r value and l value.
// go throgh abst and Encap discuss.

//--------------------------------------------------------
// oops concepts.

// what is class? it is user define datatypes just like Int .
// What is object? it is instance of class. anything that occupy space is an object.

// default constructor , copy constructor, assignment operator,move const, move assign.

// 1. Abstraction: to show neccesory information.
// access specifers used to achive the abstruction.
// to make lossely couple the two componets abstruction .

// 2. Encapsulation: to acess the data in a organised way.
// organised throgh class and objects.


// SRP achived by encapsulation.
// find out the roles of calss and define its reponsibility

// to get the right abstruction , need to get encapsulation right.


class stringClass
{
private:
	char *p = nullptr;
	int size = 0;

public:
	stringClass(char* s)
	{
		int i = 0;
		const char * t = s;
		while (*s++)
		{
			i++;
		}
		size = i + 1;
		p = new char[size];

		for (int j = 0; j < size; j++)
		{
			p[j] = t[j];
		}

		p[size] = '\0';
	}

	stringClass(const stringClass& obj)
	{
		cout << "copy constructr!" << endl;
		this->size = obj.size;
		p = new char[size + 1];

		for (int i = 0; i < size; i++)
		{
			p[i] = obj.p[i];
		}
		p[size] = '\0';
	}

	stringClass(stringClass&& obj)
	{
		cout << "move constructr!" << endl;
		this->size = obj.size;

		p =obj.p;
		obj.size = 0;
		obj.p = nullptr;
	}
		
	stringClass& operator = (stringClass&& obj)
	{
		cout << "move assignment Operator" << endl;
		if (this != &obj)
		{
			this->size = obj.size ;

			if (p != nullptr)
				delete[] p;

			p = obj.p;
			obj.size = 0;
			obj.p = nullptr;			
		}

		return *this;

	}

	stringClass& operator = (const stringClass& obj)
	{
		cout << "assignment Operator" << endl;
		if (this != &obj)
		{
			this->size = obj.size + 1;
			if (p != nullptr)
				delete[] p;

			p = new char[size];

			for (int i = 0; i < size; i++)
			{
				p[i] = obj.p[i];
			}
			p[size] = '\0';
		}

		return *this;

	}


	void print()
	{
		cout << p << endl;
	}

	~stringClass()
	{
		if (p != nullptr)
			delete[] p;
	}
	friend ostream& operator <<(ostream &os, stringClass &s);
};
ostream& operator <<(ostream &os, stringClass &s)
{
	os << s.p << endl;
	return os;
}
stringClass getistance(stringClass in)
{
	stringClass x(in);
	return x;
}


int & get()
{
	static int k;
	cout << k << endl;
	return k;
}


int main()
{





	get() = 50;
	
	cout << get();
	//cout << sizeof(stringClass) << endl;
	stringClass obj("test");
	stringClass obj2(obj);// Copy of new based on existing.
	//cout << obj2;

	obj2 = getistance(obj);// temraory nameless objet

	cout << obj;

	
	
	stringClass obj3("test3");
	cout << obj3;
	obj3 = obj2;//assignment
	
	cout << obj3;
	cin.get();
	return 0;
}

