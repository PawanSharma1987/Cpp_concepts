// MCQ.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;
class base2
{
	int x, y;
public:

	base2()
	{
		cout << "base2 cons called." << endl;

		throw 10;
	}
	~base2()
	{
		// this will be never called.
		cout << "destructor called" << endl;
	}
};
class base
{
	int x, y;
	base2 *bb2;
public:

	base() 
	{
		cout << "base cons called." << endl;
		bb2 = new base2;
		throw 10;
	}
	~base()
	{
		// this will be never called.
		cout << "destructor called" << endl;
	}
};

class first
{
private:
	int a=15;

};


class second : public first
{
	int y=10;
private:
	friend void fun();
	
};

void fun()
{
	second obj;
	first obj1;
	cout << "derived: " << obj.y << endl;
	//cout << "derived: " << obj.a << endl;
}
class A
{
public:
	int y =50;
	operator int()
	{
		return y;
	}
};

class test
{
	class A a;
	int x=20;
public:
	operator A() const
	{
		return a;
	}

	operator int()
	{
		x = a;
		return x;
	}

	A getA()
	{
		return a;
	}
};

// function oveloading is matter of scope.
// destructor can be private also.
class friendTest
{
private :
	int i;
public:
	friend void test(friendTest obj);
};

void test(friendTest obj)
{
	obj.i = 10;
	cout << obj.i << endl;
}
int main1()
{

	class test obj;

	int val1 = obj.getA();
	cout << val1 << endl;
	int val2 = obj;
	cout << "val2 :"<< val2 <<endl;

	/*try {
		base b;
		base2 b2;
		base b3;
	}
	catch (int x)
	{
		cout << "catch" << endl;
	}*/
	

//	fun();
	cin.get();
    return 0;
}

#include<iostream> 
#include<stdio.h> 

using namespace std;

class Base
{
public:
	Base()
	{
		fun(); //note: fun() is virtual 
	}
	virtual void fun()
	{
		cout << "\nBase Function";
	}
};

class Derived : public Base
{
public:
	Derived() {}
	virtual void fun()
	{
		cout << "\nDerived Function";
	}
};

int main2()
{
	Base* pBase = new Derived();
	delete pBase;
	return 0;
}

//Which fun will get called ?
// Ans Base

class constTest
{
	int i = 0;
public:
	constTest()
	{
		cout << "constTest cons is called"<< endl;
	}
	void fun()
	{
		i = 20;
		cout << "Non Const" <<i<< endl;
	}

	void fun() const
	{
		cout << "Const" << i<< endl;
	}

	~constTest()
	{
		cout << "constTest Des is called" << endl;
	}
};


int main32()
{
	const constTest obj1;
	constTest obj2;
	obj1.fun();
	obj2.fun();
	cin.get();
	return 0;
}
#include <iostream> 
using std::cout;
class main
{
public:
	main() 
	{
		cout << "ctor is called\n";

		throw 10;
	}
	~main() { cout << "dtor is called\n"; }
};
int main()
{
	{
		try {
			constTest obj;
			class main m;
		}
		catch (int x)
		{
			cout << "catch called\n";
		}
	}
	cin.get();
}
//class Test1 {
//	int y;
//};
//
//class Test2 {
//	int x;
//	Test1 t1;
//public:
//	operator Test1() { return t1; }
//	operator int() { return x; }
//};
//
//void fun23(int x) { };
//void fun23(Test1 t) { };
//// imp
//int main() {
//	Test2 t;
//	fun23(t);
//	return 0;
//}

//#include<iostream> 
//using namespace std;
//
//class A
//{
//	int x;
//public:
//	void setX(int i) { x = i; }
//	void print() { cout << x; }
//};
//
//class B : virtual  public A
//{
//public:
//	B() { setX(10); }
//};
//
//class C : virtual  public A
//{
//public:
//	C() { setX(20); }
//};
//
//class D : public B, public C {
//};
//
//int main()
//{
//	D d;
//	d.print();
//	return 0;
//}
