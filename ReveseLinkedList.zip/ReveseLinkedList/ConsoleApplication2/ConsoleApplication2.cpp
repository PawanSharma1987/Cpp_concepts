// ConsoleApplication2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;

class base
{
public:
	void fun2()
	{
		fun();
		cout << "base fun2" << endl;
	}
	virtual void fun()
	{
		cout << "base fun" << endl;
	}
};

class derived:public base
{
public:
	void fun2()
	{
		fun();
		cout << "derived fun2" << endl;
	}
	void fun()
	{

		cout << "derived fun" << endl;
	}
};

struct node
{
	struct node *link;
	int data;
};
struct node* head = nullptr;
struct node*start = nullptr;


void createList(int dataArray[], int count)
{
	for (int i = 0; i < count; ++i)
	{
		struct node* temp = new struct node;
		temp->link = nullptr;
		temp->data = dataArray[i];

		if (head == nullptr)
		{			
			head = temp;
			start = head;
		}
		else
		{
			while (head->link != nullptr)
				head = head->link;

			head->link = temp;
		}
	}	
}

struct node* reverseRicursively(struct node* ref)
{
	if (ref == nullptr || ref->link == nullptr)
		return ref;

	auto rest = reverseRicursively(ref->link);
	ref->link->link = ref; // reverse the rest part
	ref->link = nullptr;  // pointing back the first node
	return rest;
}

void print(struct node * local)
{
	while (local != nullptr)
	{
		cout << local->data;
		local = local->link;
	}
}

int main()
{

	int arrayI[5] = { 1,2,3,4,5 };

	createList(arrayI, 5);
	print(start);

	auto val = reverseRicursively(start);

	print(val);

	//derived *ptr = static_cast<derived*>(new base());//up Casting
	base *ptr = new derived;

	//ptr->fun2();// calling derived class function from base class.

	cin.get();
    return 0;
}

